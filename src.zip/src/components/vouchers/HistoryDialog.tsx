"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format as formatFns, formatDistanceToNow } from "date-fns";
import { useState, useEffect, useCallback, useMemo } from "react";
import { collection, doc, getDoc, getDocs, query, where } from "firebase/firestore";
import { firestore } from "@/lib/firebase";
import { diff } from "deep-object-diff";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { cn } from "@/lib/utils";
import { useVouchers } from "@/hooks/useVouchers";
import usePermissions from "@/hooks/usePermissions";
import { useCompany } from "@/hooks/useCompany";
import { useDate } from "@/hooks/useDate";
import { resetVoucherHistory } from "@/lib/voucher-actions";
import { Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

function renderValue(value: any) {
  if (value === null || value === undefined) return <span className="text-muted-foreground">N/A</span>;
  if (typeof value === "boolean") return <Badge variant={value ? 'default' : 'secondary'}>{value ? "Yes" : "No"}</Badge>;
  
  const isTimestamp = value?.toDate instanceof Function || (value?._seconds !== undefined && value?._nanoseconds !== undefined);
  if (isTimestamp) {
    const date = value.toDate ? value.toDate() : new Date(value._seconds * 1000);
    return date.toLocaleString();
  }

  if (typeof value === "object") return <pre className="text-xs whitespace-pre-wrap break-words bg-muted/50 p-2 rounded-md max-w-full">{JSON.stringify(value, null, 2)}</pre>;
  return <span className="break-words whitespace-normal">{String(value)}</span>;
}

function LineItemChangesRows({ from, to, renderValue }: { from: any[]; to: any[]; renderValue: (v: any) => React.ReactNode }) {
    const { processedItems, processedTaxes } = useVouchers();

    const allItemIds = [...new Set([...(from || []).map((i: any) => i.itemId), ...(to || []).map((i: any) => i.itemId)])];

    const changedItems = allItemIds.map((id: string) => {
        const oldItem = (from || []).find((i: any) => i.itemId === id);
        const newItem = (to || []).find((i: any) => i.itemId === id);

        const oldItemName = processedItems.find((pi: any) => pi.id === oldItem?.itemId)?.name || oldItem?.itemId;
        const newItemName = processedItems.find((pi: any) => pi.id === newItem?.itemId)?.name || newItem?.itemId;

        const oldTaxName = processedTaxes.find((pt: any) => pt.id === oldItem?.taxAccountId)?.name || oldItem?.taxAccountId;
        const newTaxName = processedTaxes.find((pt: any) => pt.id === newItem?.taxAccountId)?.name || newItem?.taxAccountId;

        const displayOld = { ...oldItem, itemId: oldItemName, taxAccountId: oldTaxName };
        const displayNew = { ...newItem, itemId: newItemName, taxAccountId: newTaxName };

        if (JSON.stringify(oldItem) === JSON.stringify(newItem)) return null;

        return { id, oldItem: displayOld, newItem: displayNew };
    }).filter(Boolean);

    if (changedItems.length === 0) return null;

    return (
        <>
            {changedItems.map(({ id, oldItem, newItem }: any) => {
                const itemChanges = diff(oldItem || {}, newItem || {});
                const changedKeys = Object.keys(itemChanges);
                const itemName = processedItems.find((i: any) => i.id === id)?.name || `ID: ${id}`;

                if (changedKeys.length === 0) return null;

                return (
                    <React.Fragment key={id}>
                        <TableRow className="bg-amber-50/50">
                            <TableCell className="font-medium align-top min-w-[160px] w-1/3 text-left pr-2.5 whitespace-normal break-words">
                                <span className="font-semibold">Item: {itemName}</span>
                                <span className="mx-1 text-muted-foreground">›</span>
                                <span className="text-muted-foreground">lineItems</span>
                            </TableCell>
                            <TableCell className="bg-red-50/30 min-w-[140px] w-1/3 align-top text-left px-2.5" />
                            <TableCell className="bg-green-50/30 min-w-[140px] w-1/3 align-top text-left pl-2.5" />
                        </TableRow>
                        {changedKeys.map((key) => (
                            <TableRow key={key} className="bg-amber-50">
                                <TableCell className="font-medium pl-8 min-w-[160px] w-1/3 align-top text-left pr-2.5 whitespace-normal break-words">{key}</TableCell>
                                <TableCell className="bg-red-50/60 min-w-[140px] w-1/3 align-top text-left px-2.5 whitespace-normal break-words">{renderValue(oldItem?.[key])}</TableCell>
                                <TableCell className="bg-green-50/60 min-w-[140px] w-1/3 align-top text-left pl-2.5 whitespace-normal break-words">{renderValue(newItem?.[key])}</TableCell>
                            </TableRow>
                        ))}
                    </React.Fragment>
                );
            })}
        </>
    );
}

export function HistoryDialog({ voucher, isOpen, onOpenChange, onHistoryReset }: { voucher: any; isOpen: boolean; onOpenChange: (v: boolean) => void; onHistoryReset?: () => void; }) {
  const [historyUserNames, setHistoryUserNames] = useState<Record<string, string>>({});
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const { processedParties, processedAccounts, processedStaff, processedTaxes, processedItems, expenseAccounts, userNames: vouchersUserNames } = useVouchers();
  const { can } = usePermissions();
  const { companyId } = useCompany();
  const { dateSystem, formatDate, formatDateBS } = useDate();

  const history = (voucher?.history || [])
    .filter((h: any) => h.changedAt)
    .sort((a: any, b: any) => {
        const dateA = a.changedAt?.toDate ? a.changedAt.toDate() : ( a.changedAt ? new Date(a.changedAt) : 0);
        const dateB = b.changedAt?.toDate ? b.changedAt.toDate() : ( b.changedAt ? new Date(b.changedAt) : 0);
        if (dateA instanceof Date && dateB instanceof Date) {
            return dateB.getTime() - dateA.getTime();
        }
        return 0;
    });

  const fetchUserName = useCallback(async (userId: string): Promise<string> => {
    if (historyUserNames[userId]) return historyUserNames[userId];
    if (vouchersUserNames?.[userId]) return vouchersUserNames[userId];
    try {
        const q = query(collection(firestore, "users"), where("uid", "==", userId));
        const snap = await getDocs(q);
        const byUid = snap.docs[0]?.data();
        if (byUid) {
            return byUid.displayName || byUid.name || byUid.email || userId;
        }
        const userDoc = await getDoc(doc(firestore, 'users', userId));
        if (userDoc.exists()) {
            const data = userDoc.data();
            return data.displayName || data.name || data.email || userId;
        }
    } catch (e) {}
    return userId;
  }, [historyUserNames, vouchersUserNames]);

  useEffect(() => {
    if (!isOpen) return;
    const uids = new Set<string>();
    history.forEach((h: any) => {
      if (h?.changedBy) uids.add(String(h.changedBy));
      Object.entries(h?.changes || {}).forEach(([field, values]: [string, any]) => {
        if (field === "approvedByUserId" || field === "lastEditedBy" || field === "changedBy" || field === "lastEditedByUserName") {
          if (values?.from && values.from !== "N/A") uids.add(String(values.from));
          if (values?.to && values.to !== "N/A") uids.add(String(values.to));
        }
      });
    });

    const missing = Array.from(uids).filter((uid) => !historyUserNames[uid] && !vouchersUserNames?.[uid]);
    if (missing.length === 0) return;

    let cancelled = false;
    Promise.all(missing.map(async (uid) => ({ uid, name: await fetchUserName(uid) }))).then((results) => {
      if (cancelled) return;
      setHistoryUserNames((prev) => {
        let changed = false;
        const next = { ...prev };
        results.forEach(({ uid, name }) => {
          if (!next[uid] && name) {
            next[uid] = name;
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    });
    return () => {
      cancelled = true;
    };
  }, [history, isOpen, historyUserNames, vouchersUserNames, fetchUserName]);

  const getNameById = (id: string, type: string) => {
    if (!id) return id;
    let found;
    switch(type) {
        case 'partyId': found = processedParties.find(p => p.id === id); break;
        case 'accountId': 
        case 'fromAccountId':
        case 'toAccountId':
            found = processedAccounts.find(a => a.id === id);
            return found?.accountName || id;
        case 'staffId': found = processedStaff.find(s => s.id === id); break;
        case 'taxAccountId': found = processedTaxes.find(t => t.id === id); break;
        case 'expenseAccountId':
        case 'incomeAccountId':
            found = expenseAccounts.find(e => e.id === id); break;
        case 'lastEditedBy':
        case 'approvedByUserId':
        case 'changedBy':
        case 'lastEditedByUserName':
            return historyUserNames[id] || vouchersUserNames?.[id] || id;
        default: return id;
    }
    return found?.name || id;
  }

  const handleResetHistory = async () => {
    if (!companyId || !voucher?.id) return;
    setIsResetting(true);
    try {
      await resetVoucherHistory(companyId, voucher.id);
      toast.success("Voucher history has been reset.");
      onHistoryReset?.();
      setShowResetConfirm(false);
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message || "Failed to reset history.");
    } finally {
      setIsResetting(false);
    }
  };

  const canReset = can("reset_voucher_history") && (voucher?.history?.length ?? 0) > 0;
  const getHistoryChangedAt = useCallback((changedAt: any): Date | null => {
    if (!changedAt) return null;
    if (changedAt?.toDate instanceof Function) return changedAt.toDate();
    const parsed = new Date(changedAt);
    return isNaN(parsed.getTime()) ? null : parsed;
  }, []);

  const formatModifiedDate = useCallback((changedAt: any) => {
    const changedDate = getHistoryChangedAt(changedAt);
    if (!changedDate) return "N/A";
    const dateStr = dateSystem === "BS" || dateSystem === "Both" ? formatDateBS(changedDate) : formatDate(changedDate);
    const timeStr = formatFns(changedDate, "h:mm a");
    return `${dateStr}, ${timeStr}`;
  }, [dateSystem, formatDate, formatDateBS, getHistoryChangedAt]);

  /** Renders table cell values; dates use system date format (AD/BS/Both) with time. */
  const renderCellValue = useCallback((value: any): React.ReactNode => {
    if (value === null || value === undefined) return <span className="text-muted-foreground">N/A</span>;
    const isTimestamp = value?.toDate instanceof Function || (value?._seconds !== undefined && value?._nanoseconds !== undefined);
    if (isTimestamp) {
      const date = value.toDate ? value.toDate() : new Date((value as any)._seconds * 1000);
      const dateStr = dateSystem === "BS" || dateSystem === "Both" ? formatDateBS(date) : formatDate(date);
      const timeStr = formatFns(date, "h:mm a");
      return <span className="break-words whitespace-normal">{dateStr}, {timeStr}</span>;
    }
    return renderValue(value);
  }, [dateSystem, formatDate, formatDateBS]);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-lg sm:rounded-xl left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[calc(100vw-4px)] sm:w-[calc(100vw-30px)] max-w-[calc(100vw-4px)] sm:max-w-[12in] py-6 pl-[2px] pr-[2px] sm:pl-[15px] sm:pr-[15px] h-[90vh] flex flex-col min-w-0">
        <DialogHeader>
          <DialogTitle>Voucher History #{voucher?.voucherNumber || ""}</DialogTitle>
          <DialogDescription>Last 10 modifications recorded.</DialogDescription>
        </DialogHeader>

        {/* Single scroll container: horizontal + vertical so small screens get scrollbar and no overlap */}
        <div className="flex-1 min-h-0 overflow-auto">
          <div className="space-y-6 p-1 min-w-[480px]">
            {history.length > 0 ? (
              history.map((entry: any, i: number) => (
                <div key={i} className="border rounded-lg overflow-hidden">
                  <div className="bg-muted p-3 flex flex-wrap items-start justify-between gap-2 text-sm shrink-0">
                    <p className="min-w-0 break-words"><b>User:</b> {historyUserNames[entry.changedBy] || vouchersUserNames?.[entry.changedBy] || entry.changedBy}</p>
                    <div className="text-right shrink-0">
                      <p className="text-muted-foreground">Modified: {formatModifiedDate(entry.changedAt)}</p>
                      <p className="text-muted-foreground">
                        {formatDistanceToNow(getHistoryChangedAt(entry.changedAt) || new Date(), { addSuffix: true })}
                      </p>
                    </div>
                  </div>

                  <Table className="w-full min-w-[480px]" scrollContainer={false}>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-left font-semibold min-w-[160px] w-1/3 pr-2.5">Field</TableHead>
                        <TableHead className="text-left font-semibold min-w-[140px] w-1/3 px-2.5">Old</TableHead>
                        <TableHead className="text-left font-semibold min-w-[140px] w-1/3 pl-2.5">New</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Object.entries(entry.changes).map(([field, values]: [string, any]) => {
                        if (field === 'lineItems') {
                          return (
                            <LineItemChangesRows
                              key={field}
                              from={values.from}
                              to={values.to}
                              renderValue={renderCellValue}
                            />
                          );
                        }
                        if (field === 'approvedByUserId' || field === 'approvedBy') return null;

                        const isIdField = field.toLowerCase().endsWith('id');
                        const isUserRefField = field === 'approvedByUserId' || field === 'lastEditedBy' || field === 'changedBy' || field === 'lastEditedByUserName';
                        const resolveVal = (val: any) => (isIdField || isUserRefField) ? getNameById(val, field) : val;
                        // For lastEditedBy, "New" = who made this edit; if stored "to" is empty/N/A, use entry.changedBy (same as top "User:")
                        let displayTo = values.to;
                        if (field === 'lastEditedBy' && (values.to == null || values.to === '' || String(values.to) === 'N/A')) {
                          displayTo = entry.changedBy;
                        } else if (field === 'approvedAt' && (values.to == null || values.to === '' || String(values.to) === 'N/A')) {
                          // When unapproved, "New" shows when this change happened (real date instead of N/A)
                          displayTo = entry.changedAt;
                        }

                        const fieldLabel = field === 'lastEditedByUserName' ? 'Last edited by (user name)' : field === 'lastEditedAt' ? 'Last edited date and time' : field;
                        return (
                          <TableRow key={field}>
                            <TableCell className="font-medium min-w-[160px] w-1/3 align-top text-left pr-2.5 whitespace-normal break-words">{fieldLabel}</TableCell>
                            <TableCell className="bg-red-50/60 min-w-[140px] w-1/3 align-top text-left px-2.5 whitespace-normal break-words">{renderCellValue(resolveVal(values.from))}</TableCell>
                            <TableCell className="bg-green-50/60 min-w-[140px] w-1/3 align-top text-left pl-2.5 whitespace-normal break-words">{renderCellValue(resolveVal(displayTo))}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-10">No history found for this voucher.</p>
            )}
          </div>
        </div>

        {canReset && (
          <div className="flex justify-start pt-3 border-t shrink-0">
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowResetConfirm(true)}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Reset History
            </Button>
          </div>
        )}

        <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Reset voucher history?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete all history for this voucher from the server. This cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isResetting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={(e) => { e.preventDefault(); handleResetHistory(); }}
                disabled={isResetting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isResetting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Reset History
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}
