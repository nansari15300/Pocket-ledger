
"use client";

import type { Staff } from "@/components/staff/types";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useDate } from "@/hooks/useDate";
import { useAnimationSettings } from "@/hooks/useAnimationSettings";
import { Card } from "@/components/ui/card";
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { Briefcase } from "lucide-react";
import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ResolvedEntityAvatar } from "@/components/entity/ResolvedEntityAvatar";
import {
  EntityListQuickFilterBar,
  type EntityListQuickFilter,
} from "@/components/entity/EntityListQuickFilterBar";

const getInitials = (name: string) => {
  if (!name) return "NA";
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
};

export function StaffList({
  staff,
  selectedStaff,
  onSelectStaff,
  searchTerm,
  pendingApprovalByStaffId = {},
  getItemHref,
}: {
  staff: Staff[];
  selectedStaff: Staff | null;
  onSelectStaff: (staff: Staff) => void;
  searchTerm: string;
  /** Pending approval count per staff id (only when approve notifications on list). */
  pendingApprovalByStaffId?: Record<string, number>;
  /** When provided, use Link for navigation (mobile/Capacitor) */
  getItemHref?: (staff: Staff) => string | undefined;
}) {
  const { formatCurrency } = useDate();
  const [quickFilter, setQuickFilter] = useState<EntityListQuickFilter>("default");
  const { settings: animationSettings } = useAnimationSettings();
  
  // Get animation settings - check enabled flag explicitly
  const isRowAnimationEnabled = animationSettings.rows.enabled === true;
  // Use exact duration when enabled, 0 when disabled
  const rowAnimationDuration = isRowAnimationEnabled ? animationSettings.rows.duration : 0;
  
  const filteredAndSortedStaff = useMemo(() => {
    const toDateMs = (raw: unknown): number => {
      if (!raw) return 0;
      if (raw instanceof Date) return Number.isNaN(raw.getTime()) ? 0 : raw.getTime();
      if (typeof (raw as { toDate?: () => Date }).toDate === "function") {
        const d = (raw as { toDate: () => Date }).toDate();
        return Number.isNaN(d.getTime()) ? 0 : d.getTime();
      }
      const d = new Date(raw as any);
      return Number.isNaN(d.getTime()) ? 0 : d.getTime();
    };
    const isSettled = (bal: number) => Math.abs(Number(bal || 0)) < 1e-6;
    return staff
      .filter((s) => {
        if (!s.name || !s.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
        const bal = Number(s.balance || 0);
        // Footer quick filters: list short/filter from same control on mobile + desktop.
        if (quickFilter === "dr") return bal > 0;
        if (quickFilter === "cr") return bal < 0;
        if (quickFilter === "settled") return isSettled(bal);
        if (quickFilter === "non_settled") return !isSettled(bal);
        return true;
      })
      .sort((a, b) => {
        if (quickFilter === "name") return String(a.name || "").localeCompare(String(b.name || ""));
        if (quickFilter === "date") return toDateMs(b.openingBalanceDate) - toDateMs(a.openingBalanceDate);
        return Math.abs(Number(b.balance || 0)) - Math.abs(Number(a.balance || 0));
      });
  }, [staff, searchTerm, quickFilter]);


  return (
    <div className="flex h-full min-h-0 min-w-0 flex-col rounded-b-lg border-t-0 bg-background">
      <ScrollArea className="min-h-0 min-w-0 flex-1">
        <ul className="p-2 space-y-1">
          <AnimatePresence mode="popLayout">
            {filteredAndSortedStaff.map((staffMember) => {
              const isSelected = selectedStaff?.id === staffMember.id;
              const href = getItemHref?.(staffMember);
              const cardClassName = cn(
                "min-w-0 max-w-full overflow-hidden p-1.5 cursor-pointer border rounded-md transition-all duration-200",
                isSelected
                  ? "border-primary bg-secondary shadow-sm"
                  : "border-gray-300 dark:border-gray-600 border-[1.5px] hover:border-primary/40 hover:bg-muted/30"
              );
              const cardContent = (
                <div className="pl-master-list-row">
                  <div className="pl-master-list-row-leading">
                    <div className="relative flex-shrink-0">
                      <ResolvedEntityAvatar
                        className="h-8 w-8 text-xs"
                        src={staffMember.fileUrl}
                        alt={staffMember.name}
                        fallbackSlot={<Briefcase className="h-4 w-4 text-muted-foreground" />}
                      />
                      {(pendingApprovalByStaffId[staffMember.id] ?? 0) > 0 && (
                        <span
                          className="absolute top-0 right-0 w-4 h-4 flex items-center justify-center bg-pink-500 text-white text-[10px] font-bold origin-center"
                          style={{ transform: "rotate(45deg) translate(25%, -25%)" }}
                          aria-label={`${pendingApprovalByStaffId[staffMember.id]} pending approval`}
                        >
                          <span style={{ transform: "rotate(-45deg)" }}>{pendingApprovalByStaffId[staffMember.id]}</span>
                        </span>
                      )}
                    </div>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="pl-master-list-row-name cursor-default">{staffMember.name}</span>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{staffMember.name}</p>
                        {(pendingApprovalByStaffId[staffMember.id] ?? 0) > 0 && (
                          <p className="text-xs text-muted-foreground">{pendingApprovalByStaffId[staffMember.id]} pending approval</p>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <p className={cn(
                    "pl-master-list-row-amount ml-2",
                    staffMember.balance >= 0 ? "text-green-600" : "text-red-600",
                    isSelected && (staffMember.balance >= 0 ? "text-green-800" : "text-red-800")
                  )}>
                    {formatCurrency(staffMember.balance, { showDrCr: true, context: 'list' })}
                  </p>
                </div>
              );
              return (
                <motion.li
                  key={staffMember.id}
                  layout
                  initial={false}
                  exit={{ transition: { duration: 0 } }}
                  transition={{ duration: isRowAnimationEnabled ? rowAnimationDuration : 0, ease: "easeInOut" }}
                >
                  {href ? (
                    <Link href={href} className="block min-w-0 max-w-full overflow-hidden">
                      <Card className={cardClassName}>{cardContent}</Card>
                    </Link>
                  ) : (
                    <Card className={cardClassName} onClick={() => onSelectStaff(staffMember)}>
                      {cardContent}
                    </Card>
                  )}
                </motion.li>
              );
            })}
          </AnimatePresence>
          {filteredAndSortedStaff.length === 0 && (
            <div className="text-center text-muted-foreground p-8">
              No staff members found.
            </div>
          )}
        </ul>
      </ScrollArea>
      <EntityListQuickFilterBar active={quickFilter} onChange={setQuickFilter} />
    </div>
  );
};
