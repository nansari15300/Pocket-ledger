
export const LoadingSpinner = () => (
  <div className="flex h-screen w-screen items-center justify-center bg-background">
      <div className="h-16 w-16 animate-spin rounded-full border-4 border-solid border-primary border-t-transparent"></div>
  </div>
);
