"use client";
import * as React from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar as Icon } from "lucide-react";
import { adToBs, bsToAd, type BSDate, sameBSDay, NEPALI_MONTHS, NEPALI_WEEKDAYS_SHORT } from "@/lib/bs-date";
import type { DayPicker, DateRange, SelectSingleEventHandler } from "react-day-picker";
import { cn } from "@/lib/utils";
import { useDate } from "@/hooks/useDate";
import { format, isSameDay, startOfDay } from "date-fns";
import NepaliCalendar from "@/components/ui/nepali-calendar";

type BsDatePickerBaseProps = {
  numberOfMonths?: number;
  transactionDates?: Date[];
  disabled?: boolean;
  children?: React.ReactNode;
  className?: string;
};

type BsDatePickerConditionalProps =
  | {
      isRange?: true;
      valueAD?: DateRange;
      onChangeAD: (date?: DateRange | undefined) => void;
    }
  | {
      isRange: false;
      valueAD?: Date;
      onChangeAD: (date?: Date | undefined) => void;
    };

type BsDatePickerProps = BsDatePickerBaseProps & BsDatePickerConditionalProps;


const MIN_VALID_AD_YEAR = 1944;
const MAX_VALID_AD_YEAR = 2033;

function isValidForBS(date?: Date | null): boolean {
    if (!date) return false;
    if (!(date instanceof Date)) return false;
    const time = date.getTime();
    if (isNaN(time)) return false;
    const year = date.getFullYear();
    return year >= MIN_VALID_AD_YEAR && year <= MAX_VALID_AD_YEAR;
}

export default function BsDatePicker({ valueAD, onChangeAD, numberOfMonths = 2, transactionDates = [], isRange: isRangeProp, disabled = false, children, className }: BsDatePickerProps) {
  const [open, setOpen] = React.useState(false);
  const { dateSystem, formatDateBS } = useDate();
  const isRange = isRangeProp ?? true;
  
  const handleNepaliSelect = (bsDate: BSDate, adDate: Date) => {
    // ✅ FINAL FIX: Do NOT use startOfDay. Use Noon (12:00 PM).
    
    // १. मितिको Year, Month, Day निकाल्ने (Timezone Issue हटाउन)
    const y = adDate.getFullYear();
    const m = adDate.getMonth();
    const d = adDate.getDate();

    // २. नयाँ मिति बनाउने तर समय १२ बजे (12:00:00) राख्ने
    // यसले गर्दा UTC मा जाँदा पनि दिन घट्दैन (किनकि 12:00 - 5:45 = 06:15 हुन्छ, जुन सोही दिन हो)
    const normalizedAdDate = new Date(y, m, d, 12, 0, 0, 0); 

    // ❌ startOfDay(normalizedAdDate) - यो प्रयोग नगर्नुहोस, यसले फेरि समस्या ल्याउँछ।

    if (!isRange) {
        (onChangeAD as (date?: Date) => void)(normalizedAdDate);
        setOpen(false);
    } else {
        const range = valueAD as DateRange | undefined;
        let newRange: DateRange | undefined;
        
        if (!range?.from || (range.from && range.to)) {
            // First date selection or reset - don't close calendar
            newRange = { from: normalizedAdDate, to: undefined };
        } else {
            // Second date selection - only close when both dates are set
            // समय १२ बजे भएकोले तुलना (Comparison) सही हुन्छ
            if (normalizedAdDate < range.from) {
                newRange = { from: normalizedAdDate, to: range.from };
            } else {
                newRange = { from: range.from, to: normalizedAdDate };
            }
            // Only close calendar when both from and to are set
            if (newRange.from && newRange.to) {
                setOpen(false);
            }
        }
        (onChangeAD as (date?: DateRange) => void)(newRange);
    }
  }


  const displayValue = () => {
    if (children) return children;
    if (!valueAD) return isRange ? "Pick a date range" : "Pick a date";

    if (isRange) {
        const range = valueAD as DateRange | undefined;
        if (!range?.from) return "Pick a date range";
        const fromBS = isValidForBS(range.from) ? formatDateBS(range.from) : "";
        const toBS = range.to && isValidForBS(range.to) ? formatDateBS(range.to) : "";
        if (fromBS && toBS) {
          if (fromBS === toBS) return fromBS;
          return `${fromBS} - ${toBS}`;
        }
        return fromBS;
    }

    const singleDate = valueAD as Date;
    if (!isValidForBS(singleDate)) return "Select BS Date";
    return formatDateBS(singleDate);
  }

  return (
    <Popover open={open} onOpenChange={setOpen} modal={true}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className={cn("w-auto justify-start text-left font-normal h-10 px-2 gap-1 min-w-0", !valueAD && "text-muted-foreground", className)} 
          disabled={disabled}
          onClick={() => setOpen(true)}
        >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="truncate min-w-0">{displayValue()}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-auto p-0 z-50">
        <NepaliCalendar
            onSelect={handleNepaliSelect}
            valueAD={valueAD}
            isRange={isRange}
            numberOfMonths={isRange ? numberOfMonths : 1}
            transactionDates={transactionDates}
        />
      </PopoverContent>
    </Popover>
  );
}