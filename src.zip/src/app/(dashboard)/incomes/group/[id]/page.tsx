
'use client';

import { useParams } from 'next/navigation';
import { ExpenseGroupDetails as DesktopExpenseGroupDetails } from '@/components/expenses/ExpenseGroupDetails';
import { useVouchers } from '@/hooks/useVouchers';
import { useState, useEffect, useCallback } from 'react';
import type { DateRange } from 'react-day-picker';
import { useRouter } from 'next/navigation';
import { LoadingSpinner } from '@/components/layout/LoadingSpinner';
import { useIsMobile } from '@/hooks/use-mobile';
import { doc, getDoc } from 'firebase/firestore';
import { firestore } from '@/lib/firebase';

export default function ExpenseGroupDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { processedExpenseGroups, processedExpenseAccounts, vouchers, loading } = useVouchers();
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const isMobile = useIsMobile();
  const [userNames, setUserNames] = useState<Record<string, string>>({});

  const groupId = params.id as string;

  const group = processedExpenseGroups.find((g) => g.id === groupId);
  
  const accountsInGroup = processedExpenseAccounts.filter(p => p.groupId === groupId);
  
  const fetchUserName = useCallback(async (userId: string): Promise<string> => {
    if (userNames[userId]) return userNames[userId];
    try {
        const userDoc = await getDoc(doc(firestore, 'users', userId));
        if (userDoc.exists()) {
            return userDoc.data().displayName || userDoc.data().email || "Unknown";
        }
    } catch (e) {}
    return "Unknown";
  }, [userNames]);

  useEffect(() => {
    if (!vouchers) return;
    const uids = new Set(vouchers.map((t) => t.userId).filter(Boolean) as string[]);
    const newNames: Record<string, string> = {};
    let hasNewNames = false;
    const promises = Array.from(uids).map(async (uid) => {
    if (!userNames[uid]) {
        hasNewNames = true;
        newNames[uid] = await fetchUserName(uid);
    }
    });

    Promise.all(promises).then(() => {
        if(hasNewNames) {
            setUserNames((prev) => ({ ...prev, ...newNames }));
        }
    });
  }, [vouchers, userNames, fetchUserName]);
  
  if (loading) {
    return <LoadingSpinner />;
  }

  if (!group) {
    return (
      <div className="flex items-center justify-center h-full">
        <p>Group not found.</p>
      </div>
    );
  }

  return (
    <div className="h-full min-h-0 overflow-hidden flex flex-col">
      <DesktopExpenseGroupDetails
        group={group}
        allGroups={processedExpenseGroups}
        accounts={accountsInGroup}
        onGroupUpdated={() => {}}
        onGroupDeleted={() => router.push('/incomes')}
        onAccountUpdated={() => {}}
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
        onBack={() => router.push(`/incomes?view=groups&selected=${encodeURIComponent(groupId)}`)}
        userNames={userNames}
      />
    </div>
  );
}
