
'use client';

import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { AppHeader } from "@/components/layout/AppHeader";
import { useIsMobile, MobileViewProvider } from "@/hooks/use-mobile";
import { DashboardProvider } from "@/hooks/useDashboard";
import { usePathname, useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Smartphone } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { DisclaimerDialog } from "@/components/layout/DisclaimerDialog";
import { useAuth } from "@/hooks/useAuth";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { MobileFloatingButton } from "@/components/layout/MobileFloatingButton";
import { ReportPartyViewProvider } from "@/contexts/ReportPartyViewContext";
import { ReportListProvider } from "@/contexts/ReportListContext";
import { AlarmPopup } from "@/components/messages/AlarmPopup";
import { DeviceLimitProvider, useDeviceLimitContext } from "@/contexts/DeviceLimitContext";
import { useMarkMessagesDelivered } from "@/hooks/useMarkMessagesDelivered";

function DeviceLimitBanner() {
  const { deviceLimitReached, deviceCount, maxDevices } = useDeviceLimitContext();
  if (!deviceLimitReached) return null;
  return (
    <div className="bg-amber-500 text-amber-950 text-center py-2 px-4 text-sm font-medium flex items-center justify-center gap-2 flex-wrap">
      <Smartphone className="h-4 w-4 shrink-0" />
      <span>Device limit reached ({deviceCount}/{maxDevices}). Sync from this device is blocked.</span>
      <Link href="/billing" className="underline font-semibold hover:no-underline">Upgrade to add more devices</Link>
    </div>
  );
}

function LayoutContent({ children }: { children: React.ReactNode }) {
    const isMobile = useIsMobile();
    const pathname = usePathname();
    const { user, loading } = useAuth();
    useMarkMessagesDelivered();
    const { toast } = useToast();
    const [showDisclaimer, setShowDisclaimer] = useState(false);

    // Disclaimer logic: show once per day AND on every new login session
    useEffect(() => {
        if (loading) return;

        const today = new Date().toISOString().split('T')[0];
        const lastShownDate = localStorage.getItem('lastDisclaimerShownDate');
        const sessionLoginMarker = sessionStorage.getItem('disclaimerShownForSession');

        const showForNewDay = lastShownDate !== today;
        const showForNewSession = !sessionLoginMarker;
        
        if (user && (showForNewDay || showForNewSession)) {
            setShowDisclaimer(true);
            sessionStorage.setItem('disclaimerShownForSession', 'true');
        } else if (!user) {
            // When user logs out, clear the session marker to trigger on next login
            sessionStorage.removeItem('disclaimerShownForSession');
        }
    }, [user, loading]);

    // Auto-logout only after inactivity: 20 min on mobile and desktop; activity resets the timer
    const INACTIVITY_LOGOUT_MS = 20 * 60 * 1000; // 20 minutes
    const logoutDesc = "20 minutes";

    useEffect(() => {
        if (!user) return;

        let activityTimer: ReturnType<typeof setTimeout>;

        const resetTimer = () => {
            clearTimeout(activityTimer);
            activityTimer = setTimeout(() => {
                import("@/lib/navigation-memory").then(({ clearNavigationMemory }) => clearNavigationMemory());
                signOut(auth).then(() => {
                    toast({ title: "Session Expired", description: `You have been logged out due to inactivity (${logoutDesc}).` });
                });
            }, INACTIVITY_LOGOUT_MS);
        };

        // Include touch events for mobile - any activity resets the timer
        const activityEvents: (keyof WindowEventMap)[] = [
            'mousemove', 'keydown', 'click', 'scroll',
            'touchstart', 'touchmove', 'touchend', 'touchcancel',
            'pointerdown', 'pointermove', 'wheel'
        ];

        const onActivity = () => resetTimer();

        const onVisibilityChange = () => {
            if (document.visibilityState === 'visible') resetTimer(); // User came back - reset timer
        };

        activityEvents.forEach(event => window.addEventListener(event, onActivity, { passive: true }));
        document.addEventListener('visibilitychange', onVisibilityChange);
        resetTimer();

        return () => {
            clearTimeout(activityTimer);
            activityEvents.forEach(event => window.removeEventListener(event, onActivity));
            document.removeEventListener('visibilitychange', onVisibilityChange);
        };
    }, [user, toast, INACTIVITY_LOGOUT_MS, logoutDesc]);

    const handleDisclaimerClose = () => {
        const today = new Date().toISOString().split('T')[0];
        localStorage.setItem('lastDisclaimerShownDate', today);
        setShowDisclaimer(false);
    };

    const noLayoutPages = ["/company", "/company/create"];
    const isEmbedRoute = pathname?.startsWith("/embed");

    if (noLayoutPages.includes(pathname)) {
        return (
            <>
                <DisclaimerDialog isOpen={showDisclaimer} onClose={handleDisclaimerClose} />
                {children}
            </>
        );
    }

    // Embed routes: content only (no app sidebar/header) — used when shown inside reports iframe
    if (isEmbedRoute) {
        return (
            <>
                <DisclaimerDialog isOpen={showDisclaimer} onClose={handleDisclaimerClose} />
                <div className="h-full w-full overflow-hidden bg-background">
                    {children}
                </div>
            </>
        );
    }

    return (
         <>
            <DisclaimerDialog isOpen={showDisclaimer} onClose={handleDisclaimerClose} />
            <AlarmPopup />
            <ReportListProvider>
              <ReportPartyViewProvider>
                <DeviceLimitProvider>
                  <DeviceLimitBanner />
                  <div id="app-container" className="flex h-screen bg-background">
                    <AppSidebar />
                    <div className={cn("flex flex-1 flex-col overflow-hidden", !isMobile && "border-l")}>
                      <AppHeader />
                      <main className={cn("flex-1 overflow-y-auto")}>{children}</main>
                      <MobileFloatingButton />
                    </div>
                  </div>
                </DeviceLimitProvider>
              </ReportPartyViewProvider>
            </ReportListProvider>
        </>
    )
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <MobileViewProvider>
      <SidebarProvider>
        <DashboardProvider>
          <LayoutContent>{children}</LayoutContent>
        </DashboardProvider>
      </SidebarProvider>
    </MobileViewProvider>
  );
}
